IF NOT EXISTS(SELECT * FROM sys.databases WHERE name = 'Venta')
BEGIN
	CREATE DATABASE Venta
END
GO
	USE Venta
GO

IF NOT EXISTS (SELECT * FROM sysobjects WHERE name='Usuario' and xtype='U')
BEGIN
    CREATE TABLE Usuario (
        id INT PRIMARY KEY IDENTITY (1, 1),
        nombre VARCHAR(150),
		apellido varchar(100),
		edad int,
		correo varchar(250),
		tipo_usuario varchar(100)
    )
END
go

if not exists (select * from sysobjects where name='Factura' and xtype='U')
begin
	create table Factura(
		id int primary key identity (1,1),
		id_usuario int,
		folio varchar(50),
		saldo numeric(18,2),
		fecha_facturacion smalldatetime,
		fecha_creacion smalldatetime
	)
end