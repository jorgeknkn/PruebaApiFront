﻿namespace VentasApi.Models
{
    public enum ETipoUsuario
    {
        cliente = 1, gerente = 2, administrador = 3
    }
}
