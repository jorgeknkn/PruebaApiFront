﻿using System;
using System.Collections.Generic;

#nullable disable

namespace VentasApi.Models
{
    public partial class Factura
    {
        public int Id { get; set; }
        public int? IdUsuario { get; set; }
        public string Folio { get; set; }
        public decimal? Saldo { get; set; }
        public DateTime? FechaFacturacion { get; set; }
        public DateTime? FechaCreacion { get; set; }
    }
}
