﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using System.Collections.Generic;
using System.Linq;
using System.Security.Claims;
using System.Threading.Tasks;
using VentasApi.Models;

namespace VentasApi.Controllers
{
    /// <summary>
    /// Controlador de facturas
    /// </summary>
    [Route("api/[controller]")]
    [ApiController]
    public class FacturaController : ControllerBase
    {
        /// <summary>
        /// Obtiene una lista de facturas
        /// </summary>
        /// <returns>Listado de facturas</returns>
        [HttpGet("listar")]
        [ProducesResponseType(200)]
        [Authorize]
        public async Task<ActionResult<IEnumerable<Models.Factura>>> Get()
        {
            using (var db = new Models.VentaContext())
            {
                return await db.Facturas.ToListAsync();
            }
        }

        /// <summary>
        /// Obtiene una factura
        /// </summary>
        /// <param name="id">Identificador de la factura</param>
        /// <returns>Regresa una factura</returns>
        [HttpGet("getbyid/{id}")]
        [ProducesResponseType(201)]
        [Authorize]
        public async Task<ActionResult<Models.Factura>> GetFactura(int id)
        {
            using (var db = new Models.VentaContext())
            {
                var fact = await db.Facturas.FindAsync(id);

                if (fact == null) { return NotFound(); }

                return fact;

            }
        }

        /// <summary>
        /// Crea una factura
        /// </summary>
        /// <param name="fact">Objeto factura</param>
        /// <returns>Mensaje de exito</returns>
        [HttpPost("crear")]
        [ProducesResponseType(202)]
        public async Task<ActionResult<Models.Factura>> PostFact(Factura fact)
        {
            var identity = HttpContext.User.Identity as ClaimsIdentity;

            var rToken = Jwt.ValidarToken(identity);

            if (!rToken.success) return BadRequest(rToken);

            Usuario userTk = rToken.result;

            if (userTk.tipo_usuario != "gerente")
            {
                return Forbid();
            }

            using (var db = new Models.VentaContext())
            {
                db.Facturas.Add(fact);
                await db.SaveChangesAsync();

                return Ok(new { success = true, message = "factura creada" });
            }
        }

        /// <summary>
        /// Actualiza una factura
        /// </summary>
        /// <param name="id">identificador de la factura</param>
        /// <param name="fact">Objeto factura</param>
        /// <returns>Regresa mensaje de exito</returns>
        [HttpPut("actualizar/{id}")]
        [ProducesResponseType(203)]
        public async Task<IActionResult> PutFact(int id, Factura fact)
        {
            if (id != fact.Id)
            {
                return BadRequest();
            }

            using (var db = new Models.VentaContext())
            {
                db.Entry(fact).State = EntityState.Modified;

                try
                {
                    await db.SaveChangesAsync();
                }
                catch (DbUpdateConcurrencyException)
                {
                    if (!FactExists(id))
                    {
                        return NotFound();
                    }
                    else
                    {
                        throw;
                    }
                }
            }

            return NoContent();
        }

        /// <summary>
        /// Borra una factura
        /// </summary>
        /// <param name="id">Identifcador de la factura</param>
        /// <returns>Regresa mensaje de exito</returns>
        [HttpDelete("eliminar/{id}")]
        [ProducesResponseType(204)]
        public async Task<IActionResult> DeleteFact(int id)
        {
            var identity = HttpContext.User.Identity as ClaimsIdentity;

            var rToken = Jwt.ValidarToken(identity);

            if (!rToken.success) return BadRequest(rToken);

            Usuario user = rToken.result;

            if (user.tipo_usuario != "administrador")
            {
                return Forbid();
            }

            using (var db = new Models.VentaContext())
            {
                var fact = await db.Facturas.FindAsync(id);
                if (fact == null)
                {
                    return NotFound(new { success = false, message = "No se encontro factura" });
                }

                db.Facturas.Remove(fact);
                await db.SaveChangesAsync();
            }

            return Ok(new { success = true, message = "factura borrada" });
        }

        private bool FactExists(int id)
        {
            using (var db = new Models.VentaContext())
            {
                return db.Facturas.Any(e => e.Id == id);
            }
        }
    }
}
