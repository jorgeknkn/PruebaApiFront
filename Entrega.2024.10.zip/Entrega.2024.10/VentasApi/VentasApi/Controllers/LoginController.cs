﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using Microsoft.IdentityModel.Tokens;
using System;
using System.IdentityModel.Tokens.Jwt;
using System.Linq;
using System.Security.Claims;
using System.Text;
using System.Threading.Tasks;
using VentasApi.Models;

namespace VentasApi.Controllers
{
    [Route("Usuario")]
    [ApiController]
    public class LoginController : ControllerBase
    {
        private readonly IConfiguration _configuration;
        public LoginController(IConfiguration configuration)
        {
            _configuration = configuration;
        }

        [HttpPost]
        [Route("login")]
        public async Task<IActionResult> Login([FromBody] string userLogin)
        {
            using (var db = new Models.VentaContext())
            {
                var data = await db.Usuarios.Where(w => w.Nombre == userLogin).FirstOrDefaultAsync();

                if (data == null) return NotFound();

                var jwt = _configuration.GetSection("Jwt").Get<Jwt>();

                var claims = new[]
                {
                    new Claim(JwtRegisteredClaimNames.Sub, jwt.Subject),
                    new Claim(JwtRegisteredClaimNames.Jti, Guid.NewGuid().ToString()),
                    new Claim(JwtRegisteredClaimNames.Iat, DateTime.UtcNow.ToString()),
                    new Claim("id", data.Id.ToString()),
                    new Claim("usuario",data.Nombre)
                };

                var key = new SymmetricSecurityKey(Encoding.UTF8.GetBytes(jwt.key));
                var singIn = new SigningCredentials(key, SecurityAlgorithms.HmacSha256);

                var token = new JwtSecurityToken(
                        jwt.Issuer,
                        jwt.Audience,
                        claims,
                        expires: DateTime.UtcNow.AddMinutes(60),
                        signingCredentials: singIn
                    );

                return Ok(new { success = true, Mensaje = "Operación exitosa", result = new JwtSecurityTokenHandler().WriteToken(token) });
            }
        }
    }
}
