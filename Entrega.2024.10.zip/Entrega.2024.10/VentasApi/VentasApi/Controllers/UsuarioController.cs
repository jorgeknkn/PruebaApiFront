﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Security.Claims;
using System.Threading.Tasks;
using VentasApi.Models;

namespace VentasApi.Controllers
{
    /// <summary>
    /// Controlador de usuario
    /// </summary>
    [Route("api/[controller]")]
    [ApiController]
    public class UsuarioController : ControllerBase
    {
        /// <summary>
        /// Obtiene una lista de usuarios
        /// </summary>
        /// <returns>Lista de usuarios</returns>
        [HttpGet("listar")]
        [ProducesResponseType(200)]
        public async Task<ActionResult<IEnumerable<Models.Usuario>>> Get()
        {
            using (var db = new Models.VentaContext())
            {
                return await db.Usuarios.ToListAsync();
            }
        }

        /// <summary>
        /// Obtiene un usuario
        /// </summary>
        /// <param name="id">identificador del usuario</param>
        /// <returns>Regresa un objeto usuario</returns>
        [HttpGet("getbyid/{id}")]
        [ProducesResponseType(201)]
        public async Task<ActionResult<Models.Usuario>> GetUser(int id)
        {
            using (var db = new Models.VentaContext())
            {
                var user = await db.Usuarios.FindAsync(id);

                if (user == null) { return NotFound(); }

                return user;

            }
        }

        /// <summary>
        /// Crea un usuario
        /// </summary>
        /// <param name="user">Objeto usuario</param>
        /// <returns>Mensaje de exito</returns>
        [HttpPost("crear")]
        [ProducesResponseType(202)]
        public async Task<ActionResult> PostUser(Usuario user)
        {
            var identity = HttpContext.User.Identity as ClaimsIdentity;

            var rToken = Jwt.ValidarToken(identity);

            if (!rToken.success) return BadRequest(rToken);

            Usuario userTk = rToken.result;

            if (userTk.tipo_usuario != "gerente")
            {
                return Forbid();
            }

            using (var db = new Models.VentaContext())
            {
                db.Usuarios.Add(user);
                await db.SaveChangesAsync();

                return Ok(new { success = true, message = "Usuario creado" });
            }
        }

        /// <summary>
        /// Actualiza un usuario
        /// </summary>
        /// <param name="id">Identificador del usuario</param>
        /// <param name="user">Objeto usuario</param>
        /// <returns>Mensaje de exito</returns>
        [HttpPut("actualizar/{id}")]
        [ProducesResponseType(203)]
        public async Task<IActionResult> PutUser(int id, Usuario user)
        {
            if (id != user.Id)
            {
                return BadRequest();
            }

            using (var db = new Models.VentaContext())
            {
                db.Entry(user).State = EntityState.Modified;

                try
                {
                    await db.SaveChangesAsync();
                }
                catch (DbUpdateConcurrencyException)
                {
                    if (!UserExists(id))
                    {
                        return NotFound();
                    }
                    else
                    {
                        throw;
                    }
                }
            }

            return NoContent();
        }

        /// <summary>
        /// Borra un usuario
        /// </summary>
        /// <param name="id">Identificador del usuario</param>
        /// <returns>Mensaje de exito</returns>
        [HttpDelete("eliminar/{id}")]
        [ProducesResponseType(204)]
        public async Task<IActionResult> DeleteUser(int id)
        {
            var identity = HttpContext.User.Identity as ClaimsIdentity;

            var rToken = Jwt.ValidarToken(identity);

            if (!rToken.success) return BadRequest(rToken);

            Usuario user = rToken.result;

            if (user.tipo_usuario != "administrador")
            {
                return Forbid();
            }

            using (var db = new Models.VentaContext())
            {
                var userToDel = await db.Usuarios.FindAsync(id);
                if (userToDel == null)
                {
                    return NotFound(new { success = false, message = "No se encontro el usuario" });
                }

                db.Usuarios.Remove(userToDel);
                await db.SaveChangesAsync();
            }

            return Ok(new { success = true, message = "Usuario borrado" });
        }

        private bool UserExists(int id)
        {
            using (var db = new Models.VentaContext())
            {
                return db.Usuarios.Any(e => e.Id == id);
            }
        }
    }
}
