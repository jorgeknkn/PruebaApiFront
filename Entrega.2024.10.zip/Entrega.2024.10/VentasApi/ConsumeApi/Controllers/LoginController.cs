﻿using Microsoft.AspNetCore.Mvc;
using System.Net.Http;
using System;
using ConsumeApi.Models;
using Newtonsoft.Json;
using System.Collections.Generic;
using System.Threading.Tasks;
using System.Reflection;
using System.Net.Http.Json;
using System.Text;
using Microsoft.AspNetCore.Http;

namespace ConsumeApi.Controllers
{
    public class LoginController : Controller
    {
        private readonly IHttpClientFactory _httpClientFactory;

        public LoginController(IHttpClientFactory httpClientFactory)
        {
            _httpClientFactory = httpClientFactory;
        }

        [HttpGet]
        public IActionResult Index()
        {
            return View();
        }

        [HttpPost]
        public async Task<IActionResult> Authenticate(string Username)
        {
            var client = _httpClientFactory.CreateClient();

            var loginData = new
            {
                username = Username
            };

            var jsonContent = new StringContent(JsonConvert.SerializeObject(loginData), Encoding.UTF8, "application/json");

            var response = await client.PostAsync("https://localhost:44301/Usuario/login", jsonContent);

            if (response.IsSuccessStatusCode)
            {
                // Leer el contenido de la respuesta (por ejemplo, un token JWT)
                var token = await response.Content.ReadAsStringAsync();

                // Almacenar el token en sesión o cookies (según sea tu caso)
                HttpContext.Session.SetString("AuthToken", token);

                // Redirigir a la página principal u otra página protegida
                return RedirectToAction("Index", "Usuario");
            }
            else
            {
                // Si el login falla, mostrar el mensaje de error
                //model.ErrorMessage = "Login fallido. Usuario o contraseña incorrectos.";
                return View("Index", "Usuario");
            }
        }
    }
}
