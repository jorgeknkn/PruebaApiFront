﻿using ConsumeApi.Models;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Net.Http;
using System.Text.Json.Serialization;
using Newtonsoft.Json;

namespace ConsumeApi.Controllers
{
    public class UsuarioController : Controller
    {
        Uri dirBase = new Uri("https://localhost:44301/api");
        private readonly HttpClient _client;

        public UsuarioController()
        {
            _client = new HttpClient();
            _client.BaseAddress = dirBase;
        }

        [HttpGet]
        public IActionResult Index()
        {
            List<UsuarioViewModel> userList = new List<UsuarioViewModel>();
            HttpResponseMessage response = _client.GetAsync(_client.BaseAddress + "/Usuario/listar").Result;
            if (response.IsSuccessStatusCode)
            {
                string data = response.Content.ReadAsStringAsync().Result;
                userList = JsonConvert.DeserializeObject<List<UsuarioViewModel>>(data);
            }
            return View(userList);
        }
    }
}
