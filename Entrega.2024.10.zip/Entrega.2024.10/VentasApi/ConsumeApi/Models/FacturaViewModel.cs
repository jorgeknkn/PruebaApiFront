﻿using System;

namespace ConsumeApi.Models
{
    public class FacturaViewModel
    {
        public int Id { get; set; }
        public int? IdUsuario { get; set; }
        public string Folio { get; set; }
        public decimal? Saldo { get; set; }
        public DateTime? FechaFacturacion { get; set; }
        public DateTime? FechaCreacion { get; set; }
    }
}
